
function generateDescription(file) {
    var imagePreview = document.getElementById("imagePreview");
    var generatedText = document.getElementById("generatedText");
    if (file) {
        var reader = new FileReader();
        reader.onload = function (e) {
            var img = new Image();
            img.src = e.target.result;
            imagePreview.innerHTML = '';
            imagePreview.appendChild(img);
        };
        reader.readAsDataURL(file);
        generatedText.textContent = "Uploaded image: " + file.name;
    } else {
        imagePreview.innerHTML = "";
        generatedText.textContent = "No image uploaded.";
    }
}

function speakDescription() {
    var generatedText = document.getElementById("generatedText").textContent;
    var speechSynthesis = window.speechSynthesis;
    var speechMsg = new SpeechSynthesisUtterance(generatedText);
    speechSynthesis.speak(speechMsg);
}

document.getElementById("imageUpload").addEventListener("change", function(e) {
    generateDescription(e.target.files[0]);
});

document.getElementById("captureBtn").addEventListener("click", function() {
    var fileInput = document.getElementById("imageUpload");
    if (fileInput.files.length > 0) {
        generateDescription(fileInput.files[0]);
    }
});

document.getElementById("captureBtn").addEventListener("click", function() {
    setTimeout(function() {
        navigator.mediaDevices.getUserMedia({ video: true })
        .then(function(stream) {
            var video = document.createElement("video");
            video.srcObject = stream;
            video.onloadedmetadata = function(e) {
                video.play();
                var canvas = document.createElement("canvas");
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                var ctx = canvas.getContext("2d");
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(function(blob) {
                    generateDescription(blob);
                });
                stream.getVideoTracks()[0].stop();
            };
        })
        .catch(function(err) {
            console.error("Error accessing camera:", err);
        });
    }, 1000); // 2000 milliseconds = 2 seconds
});

document.getElementById("audioBtn").addEventListener("click", speakDescription);
